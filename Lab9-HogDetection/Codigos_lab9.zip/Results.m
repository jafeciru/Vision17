% clear all; close all; clc
addpath('Funciones')
mkdir('Detecciones')
d = dir('data\WIDER_val\images');
d = d(3:end);
names = {d.name};
for i = 1:length(names)
    mkdir(fullfile('Detecciones',names{i}))
end
setup ;
NomImagenesTest
load('NombresImagenesTest.mat')
l = length(NombresImagenesTest);
load('model.mat')
%% Espacial
hogCellSize = 8 ;
minScale = -1 ;
maxScale = 3 ;
numOctaveSubdivisions = 3 ;
scales = 2.^linspace(minScale,maxScale,numOctaveSubdivisions*(maxScale-minScale+1)) ;
%%
disp('Entrando')
for i = 1:100:l
    pause
    tot = NombresImagenesTest{i};
    im = imread(tot);
    im = im2single(im);
    C = strsplit(tot,'\');
    nombre = C{end};
try
    [detections, scores] = detect(im, w, hogCellSize, scales) ;
catch error
    continue
end
    % Non-maxima suppression
    scores = scores/max(scores(:));
    keep = boxsuppress(detections, scores,  0.9);
    detections = detections(:, keep) ;
    scores = scores(keep) ;
    detections = detections(:,1:5);
    scores = scores(1:5);
    numero = numel(scores);
    total = [detections;scores]';
    figure(1); clf;
    imagesc(im) ; axis equal ;
    hold on ;
    vl_plotbox(detections, 'g', 'linewidth', 1) ;
    nomTxt = fullfile('Detecciones',C{4},[nombre(1:end-3) 'txt']);
    fi = fopen(nomTxt,'w');
    fprintf(fi,'%s\n %f\n',nombre(1:end-4), numero);
    fprintf(fi,'%f %f %f %f %f\n',total');
    fclose(fi);
    disp(['SVM. Imagen de test #' num2str(i)])
end
save('ResultadosSVM.mat','Resultado')