DireccionInicial = 'data/WIDER_val/images';
dTotal = dir(DireccionInicial);
dTotal = dTotal(3:end);
ltotal = length(dTotal);
NombresImagenesTest = {};
cont = 0;
for i = 1:ltotal
    nombreCarpeta = dTotal(i).name;
    dCarpeta = dir(fullfile(DireccionInicial,nombreCarpeta));
    dCarpeta = dCarpeta(3:end);
    limagenes = length(dCarpeta);
    for j = 1:limagenes
        cont = cont+1;
        nombreImagen = dCarpeta(j).name;
        NombresImagenesTest{cont} = fullfile(DireccionInicial,nombreCarpeta,nombreImagen);
    end
end
save('NombresImagenesTest.mat','NombresImagenesTest');