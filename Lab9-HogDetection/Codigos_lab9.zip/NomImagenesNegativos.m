%% Generando Negativos

rutneg = 'data/neg';
mkdir(rutneg)
d = dir('caltech-101');
d = d(3:end);
l = length(d);
NombresImagenesNegativos = {};
cont = 0;
for i = 1:l
    carpeta = d(i).name;
    nom = fullfile('caltech-101',carpeta);
    dcarp = dir(nom);
    dcarp = dcarp(3:end);
    mkdir(fullfile(rutneg,carpeta))
    for j = 1:10
        cont = cont+1;
        nombreIm = dcarp(j).name;
        tot = fullfile('caltech-101',carpeta,nombreIm);
%         imagen = imread(tot);
        nuevoNom = fullfile(rutneg,carpeta,nombreIm);
%         imwrite(imagen,nuevoNom)
        NombresImagenesNegativos{cont} = nuevoNom;
    end
end
save('NombresImagenesNegativos.mat','NombresImagenesNegativos')