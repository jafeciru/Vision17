clear all; close all; clc
indices = cell(8,3);
indices{1,1} = '24063.mat';indices{1,2} = 1;
indices{2,1} = '25098.mat';indices{2,2} = 6;
indices{3,1} = '26031.mat';indices{3,2} = 6;
indices{4,1} = '27059.mat';indices{4,2} = 2;
indices{5,1} = '48055.mat';indices{5,2} = 4;
indices{6,1} = '54005.mat';indices{6,2} = 4;
indices{7,1} = '55067.mat';indices{7,2} = 2;
indices{8,1} = '55075.mat';indices{8,2} = 4;
d = dir('lab5images');
datos = d(3:end);
l = length(datos)/2;
for i = 1:l
    clear nom
    nom = string(indices{i,1});
    full = fullfile('Lab5Images',nom);
    gt=load(full);
    ground = gt.groundTruth;
    segm = ground{indices{i,2}}.Segmentation;
    indices{i,3} = segm;
end
A = load('Resultados6Clust2.mat');
B = A.Completo;
s = size(B);
Jac = cell(s(1),2);
for i = 1:s(1)
    C = B{i,1};
    label2 = indices{i,3};
    Jac2 = cell(2,2);
    for j = 1:2
        D = C{j,1};
        s2 = size(D);
        Jac1 = cell(s2(1),s2(2));
        for x = 1:s2(1);
            clear label
            label = label2;
            met = D{x,2};
            imagen = D{x,1};
            if isempty(imagen)
                Jo = 0;
            else
                if isequal(met,'jerarquica')
                    label = imresize(label,size(imagen));
                elseif isequal(met,'watersheds')
                    label = cat(2,label,label,label);
                end
                Jo = Jaccard(imagen,label);
            end
            Jac1{x,1} = Jo;
            Jac1{x,2} = D{x,2};
            Jac1{x,3} = D{x,3};
        end
        Jac2{j,1} = Jac1;
        Jac2{j,2} = C{j,2};
    end
    Jac{i,1} = Jac2;
    Jac{i,2} = B{i,2};
end