A = load('IndJac.mat');
B = A.Jac;
s = length(B);
Filas = length(B)*length(B{1})*(length(B{1}{1})-3);
Columnas = 5;
TotalJaccards = cell(Filas,Columnas);
indices = cell(Filas,1);
cont = 0;
for i = 1:s(1)
    imClusts = B{i,1};
    nombreImagen = B{i,2};
    for j = 1:2
        imTotales = imClusts{j,1};
        clust = imClusts{j,2};
        l = length(imTotales);
        for f = 1:l-3
            cont = cont+1;
%             Jaccard = imTotales{f,1};
%             Metodo = imTotales{f,2};
%             Espacio = imTotales{f,3};
            TotalJaccards{cont,1} = imTotales{f,1};
            TotalJaccards{cont,2} = imTotales{f,2};
            TotalJaccards{cont,3} = imTotales{f,3};
            TotalJaccards{cont,4} = num2str(clust);
            TotalJaccards{cont,5} = nombreImagen;
            Indices{cont,1} = imTotales{f,1};
        end
    end
end
Ind = cell2mat(Indices);

IndOrd = sort(Ind,'descend');
mx1 = IndOrd(1);
loc1 = find(Ind == mx1);
D1 = [num2str(TotalJaccards{loc1,1}) '  ' TotalJaccards{loc1,2} '  '  TotalJaccards{loc1,3} '  '  TotalJaccards{loc1,4} '  '  TotalJaccards{loc1,5}];
mx2 = IndOrd(2);
loc2 = find(Ind == mx2);
D2 = [num2str(TotalJaccards{loc2,1}) '  ' TotalJaccards{loc2,2} '  '  TotalJaccards{loc2,3} '  '  TotalJaccards{loc2,4} '  '  TotalJaccards{loc2,5}];
mx3 = IndOrd(3);
loc3 = find(Ind == mx3);
D3 = [num2str(TotalJaccards{loc3,1}) '  ' TotalJaccards{loc3,2} '  '  TotalJaccards{loc3,3} '  '  TotalJaccards{loc3,4} '  '  TotalJaccards{loc3,5}];
disp(['Maximo 1: ' D1])
disp(['Maximo 2: ' D2])
disp(['Maximo 3: ' D3])
save('Tot.xlsx','TotalJaccards')    
% IndP = sort(Ind);
% IndOrdP = sort(IndP);
% while IndOrdP(1) < 0.0005
%     IndOrdP = IndOrdP(2:end);
% end
% mn1 = IndOrdP(1);
% locP1 = find(IndP == mn1);
% P1 = [num2str(TotalJaccards{locP1(1),1}) '  ' TotalJaccards{locP1(1),2} '  '  TotalJaccards{locP1(1),3} '  '  TotalJaccards{locP1(1),4} '  '  TotalJaccards{locP1(1),5}];
% mn2 = IndOrdP(2);
% locP2 = find(IndP == mn2);
% P2 = [num2str(TotalJaccards{locP2(1),1}) '  ' TotalJaccards{locP2(1),2} '  '  TotalJaccards{locP2(1),3} '  '  TotalJaccards{locP2(1),4} '  '  TotalJaccards{locP2(1),5}];
% mn3 = IndOrdP(3);
% locP3 = find(IndP == mn3);
% P3 = [num2str(TotalJaccards{locP3(1),1}) '  ' TotalJaccards{locP3(1),2} '  '  TotalJaccards{locP3(1),3} '  '  TotalJaccards{locP3(1),4} '  '  TotalJaccards{locP3(1),5}];
% disp(['Peor 1: ' P1])
% disp(['Peor 2: ' P2])
% disp(['Peor 3: ' P3])