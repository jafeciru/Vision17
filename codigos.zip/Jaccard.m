function Jo = Jaccard(imagen,segm)
mx = mode(mode(imagen));
f = find(imagen == mx);
C = zeros(size(imagen));
C(f) = 1;
mx2 = mode(mode(segm));
f2 = find(segm == mx2);
Cs = zeros(size(segm));
Cs(f2) = 1;
O = or(C,Cs);
Y = and(C,Cs);
suO = sum(O(:));
suY = sum(Y(:));
Jo = suY/suO;
end
% image(segm)
% colormap colorcube
% 
% % create a new figure
% figure
% % Boundaries from first human
% bound=t.groundTruth{1}.Boundaries;
% image(bound)
% colormap flag