function  imResultado = Segmentation( imagen,Metodo,tipo,k )
%close all; clear all
imagen = double(imagen);
l = length(tipo);
tip = tipo(1:3);
if isequal(Metodo,'jerarquica');
    imagen = imresize(imagen,0.3);
end
switch tip
    case 'rgb'
        im = imagen./max(imagen(:));
    case 'lab'
        mn = min(min(min(imagen)));
        mx = max(max(max(imagen))); 
        im = (imagen+abs(mn))/(abs(mx)+abs(mn));
    case 'hsv'
        im = rgb2hsv(imagen);
end
s = size(im);
if l == 6
    [x,y] = meshgrid(1:s(2),1:s(1));
    x = x./max(max(x));
    y = y./max(max(y));
    im = cat(3,im,x,y);
    estado = true;
else
    estado = false;
end
%%
[~,~,dim] = size(im);
D = double(reshape(im,[],dim));
%%
switch Metodo
    case 'k means'
        [map, ~] = kmeans(D,k);
        imResultado = reshape(map,s(1),s(2));
    case 'gmnm'
        try
	     gm = fitgmdist(D,k);
             idx = cluster(gm,D);
	     imResultado = reshape(idx,s(1),s(2));
	catch error
	     imResultado = 0;
	end
    case 'jerarquica'
%         Y = pdist(D,'hamming');
        Z = linkage(D,'ward','euclidean','savememory','on');
        T = cluster(Z,'maxclust',k);
        imResultado = reshape(T,s(1),s(2));
    case 'watersheds'
        if estado
            imResultado = 0;
            return
        end
        a = strel('disk',1);
        b = strel('disk',1);
        imResult = zeros(size(im));
        for i = 1:3
            imagenC = im(:,:,i);
            imwat = imdilate(imagenC,a)-imerode(imagenC,a);
            if isequal(tipo,'hsv')
                umbral = 0.1;
            else
                umbral = graythresh(imwat);
            end
            inv = not(im2bw(imwat,umbral));
            clust = 0;
            while clust ~= k
                imer = imerode(inv,b);
                clust = max(max(bwlabel(imer)));
                if k > clust
                    imResultado = 0;
		    return
                end
                inv = imer;
            end
            Minim = imimposemin(imagenC,imer);
            L = watershed(Minim);
            imResult(:,:,i) = L;
        end
        imResultado = cat(2,imResult(:,:,1),imResult(:,:,2),imResult(:,:,3));
end
end
