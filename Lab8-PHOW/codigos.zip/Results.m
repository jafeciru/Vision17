%%Esta funcion muestra los resultados para cada parametro de cambio. 
d = dir('Results');
d = d(3:end);
l = length(d);
for i = 1:l
    pause
    nombre = d(i).name;
    load(fullfile('Results',nombre))
    imagesc(confus)
    if isequal(nombre,'baseline-result.mat')
        nt = 15;
    elseif isequal(nombre,'baselinenumTest40-result.mat')
        nt = 40;
    elseif isequal(nombre,'baselinenumTest10-result.mat')
        nt = 10;
    else 
        nt =25;
    end
    ACA = 100*mean(diag(confus)/25);
    title([nombre '. El ACA es:   ', num2str(ACA)])
end
