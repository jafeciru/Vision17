load('Test/baselineDefinitivoTest-result.mat');
load('Test/baselineDefinitivoTest-model.mat');
ACA = mean(diag(confus)/25)*100;
d = diag(confus);
ind = find(d == 0);
classes = model.classes;
cD = cell(length(ind),1);
for i = 1:length(ind)
    cD{i} = classes{ind(i)};
end
s = sort(d,'descend');
indmax1 = find(d == s(1));
classmax1 = classes{indmax1};
indmax2 = find(d == s(2));
classmax2 = classes{indmax2};
indmax3 = find(d == s(3));
indmax3 = indmax3(1);
classmax3 = classes{indmax3};