function [ imResultado ] = SegmentationBSDS( imagen, tipo,Metodo,k )
imagen = double(imagen);
s = size(imagen);
%cambia el espacio de color de acuerdo al parametro.. 
switch tipo
    case 'rgb'
        mx = max(max(max(imagen)));
        im = imagen./mx;
    case 'hsv'
        im = rgb2hsv(imagen);
    case 'lab'
        im = rgb2lab(imagen);
        mn = min(min(min(im)));
        mx = max(max(max(im)));
        im = (im+abs(mn))/(abs(mx)+abs(mn));
        % Para los espacios de color, con espacio incluido, se genera un
        % meshgrid normalizado
    case 'rgb+xy'
        mx = max(max(max(imagen)));
        im = imagen./mx;
        [x,y] = meshgrid(1:s(2),1:s(1));
        x = x./max(max(x));
        y = y./max(max(y));
        im = cat(3,im,x,y);
    case 'hsv+xy'
        im = rgb2hsv(imagen);
        [x,y] = meshgrid(1:s(2),1:s(1));
        x = x./max(max(x));
        y = y./max(max(y));
        im = cat(3,im,x,y);
    case 'lab+xy'
        im = rgb2lab(imagen);
        mn = min(min(min(im)));
        mx = max(max(max(im)));
        im = (im+abs(mn))/(abs(mx)+abs(mn));
        [x,y] = meshgrid(1:s(2),1:s(1));
        x = x./max(max(x));
        y = y./max(max(y));
        im = cat(3,im,x,y);
end
[~,~,dim] = size(im);
D = double(reshape(im,[],dim)); % Reorganiza el espacio de representacion en una matriz
switch Metodo
    case 'k means'
        [map, ~] = kmeans(D,k); %Halla los centroides y el mapa. Se omiten los centroides
        imResultado = reshape(map,s(1),s(2)); %Se reorganiza el mapa para que se vea como la imagen
    case 'gmm'
        gm = fitgmdist(D,k,'SharedCovariance',true); %Genera funciones gaussianas para cada cluster. 
        idx = cluster(gm,D); %Asigna a cada valor un cluster
        imResultado = reshape(idx,s(1),s(2)); %Se reorganiza el mapa para que se vea como la imagen
end

