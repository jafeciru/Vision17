%% Metodo de segmentacion
%Este codigo genera las segmentaciones para las carpetas de training, test
%y validacion. De ser necesario se debe cambiar todos los strings con el
%nombre de la carpeta. 
ks = [12 15 18 20];%Vector de clusters
s = length(ks);
carpeta = fullfile('BSR','BSDS500','data','images');
d = dir(fullfile(carpeta,'train'));
d = d(3:end-1);
l = length(d);

for j = 1:s
    %Crea carpetas para cada cluster
    k = ks(j);
    Res = ['Resultados' num2str(k)];
    mkdir(fullfile('Resultados',Res))
    %Recorre cada una de las imagenes en la carpeta seleccionada
    for i = 1:l
        nom = d(i).name;
        nombre = fullfile(carpeta,'train',nom);
        imagen = imread(nombre);
        %Genera las dos segmentaciones
        segmK = SegmentationBSDS(imagen,'lab','k means',k);
        segmG = SegmentationBSDS(imagen,'rgb','gmm',k);
        %asigna un cell con cada segmentacion. cell de 2
        segs = cell(1,2);
        segs{1} = segmK;
        segs{2} = segmG;
        %Guarda en la carpeta seleccionada, para cada cluster. Tiene el
        %mismo nombre que la imagen pero en formato .mat
        nomC = [nom(1:end-4) '.mat'];
        nomCC = fullfile('Resultados',Res,nomC);
        save(nomCC,'segs')
    end
end
