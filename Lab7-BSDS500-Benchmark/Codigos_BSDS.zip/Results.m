%% Resultados Test
%Para training y validation se realizo con el mismo codigo exceptuando la
%ultima seccion. De ser necesario se cambia cada "test" por un "train" o
%"validation". 
addpath BSR/bench_fast/benchmarks
%% Genera la evaluacion para K means entrenamiento
clear all;close all;clc;
imgDir = 'BSR/BSDS500/data/images/test';
gtDir = 'BSR/BSDS500/data/groundTruth/test';
inDir = 'Eval/Test/K means Test';
outDir = 'Results/Test/K Test';
mkdir(outDir);
nthresh = 5;

tic;
allBench_fast(imgDir, gtDir, inDir, outDir, nthresh);
plot_eval(outDir)
TK = toc;
%% Genera la evaluacion para Gmm entrenamiento
clear all;close all;clc;
imgDir = 'BSR/BSDS500/data/images/test';
gtDir = 'BSR/BSDS500/data/groundTruth/test';
inDir = 'Eval/Test/Gmm Test';
outDir = 'Results/Test/Gmm Test';
mkdir(outDir);
nthresh = 5;

tic;
allBench_fast(imgDir, gtDir, inDir, outDir, nthresh);
plot_eval(outDir)
TK = toc;

%% Genera las graficas para test. Este muestra K means, Gmm y UCM
outDirKmeans = 'Results/Test/K Test';
outDirGmm = 'Results/Test/Gmm Test';
outDirUCM2 = 'BSR/BSDS500/ucm2/test_eval';
plot_eval1(outDirKmeans,'r');
plot_eval2(outDirGmm,'b');
plot_eval2(outDirUCM2,'y')
legend('K means','Gmm','ucm2')